import math as m

obj_list = []

def instance_create(x,y,obj):
    obj_list.append(obj(x,y))
    return obj_list[-1]

def instance_destroy(args):
    for i in obj_list:
        if i==args:
            obj_list.remove(i)
            return True
            break
    for i in obj_list:
        if isinstance(i,args):
            obj_list.remove(i)

def point_distance(x1, y1, x2, y2):
    return m.hypot(x1-x2, y1-y2)