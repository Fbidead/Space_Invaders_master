import pygame as pg 
import util as ul
import math as m

pg.init() #initialization of pygame

rm_width=721
rm_height=662

win = pg.display.set_mode((rm_width,rm_height)) #screen res
pg.display.set_caption("Space Invaders") #title

draw_rectangle = pg.draw.rect

class sprite: # class of sprite object
    def __init__(self,index,width,height):
        self.index=index #image
        self.height=height #image height
        self.width=width #image width 

#sprite init
spr_player = sprite(pg.image.load("assets/spr_player.png"),53,30)
spr_allien1 = sprite([pg.image.load("assets/spr_allien1_1.png"),
                    pg.image.load("assets/spr_allien1_2.png")],26,26)
spr_allien2 = sprite([pg.image.load("assets/spr_allien2_1.png"),
                    pg.image.load("assets/spr_allien2_2.png")],37,27)
spr_allien3 = sprite([pg.image.load("assets/spr_allien3_1.png"),   
                    pg.image.load("assets/spr_allien3_2.png")],39,26)

class obj: #main obj class
    x=0
    y=0
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.create()

    def draw_self(self,frame=0):
        if type(self.sprite.index)==list:
            win.blit(self.sprite.index[frame],(self.x-self.sprite.width//2,self.y-self.sprite.height//2))
        else:
            win.blit(self.sprite.index,(self.x-self.sprite.width//2,self.y-self.sprite.height//2))
            

class obj_alliens(obj): #obj player
    alive=False
    move=1
    speed=35
    animFrame=0
    def create(self):
        self.alarm = [-1,-1]
    def step(self):
        for i in range(2):
            if self.alarm[i]!=-1:
                self.alarm[i]-=1

        obj_alliens.alive=True

        if self.move<0 and self.x<16 or self.move>0 and self.x>rm_width-16:  
            if obj_alliens.move==1:
                for i in ul.obj_list:
                    if isinstance(i,obj_alliens):
                        i.y+=32
            obj_alliens.move=-obj_alliens.move

    
        if self.alarm[0]==-1:
            self.x+=self.move*5
            if self.animFrame<1:
                self.animFrame+=1
            else:
                self.animFrame-=1
            self.alarm[0]=self.speed
    def draw(self):
        self.draw_self(self.animFrame)


class obj_bulletPlayer(obj):
    def create(self):
        pass
    def step(self):
        self.y-=10
        for i in ul.obj_list:
            if isinstance(i,obj_alliens):
                if ul.point_distance(self.x,self.y,i.x,i.y) < 20:
                    ul.instance_destroy(i)
                    ul.instance_destroy(self)
        if self.y < 0:
            ul.instance_destroy(self)

    def draw(self):
        draw_rectangle(win,(255,0,0),(self.x-4//2,self.y-16//2,4,16))


class obj_player(obj): #obj player
    def create(self):
        self.score=0
        self.sprite=spr_player
        self.hsp=0
        self.speed=3
    def step(self):
        global keys #list with keys 
        self.hsp=keys[pg.K_d]-keys[pg.K_a] #horizontal speed

        if keys[pg.K_SPACE]:
            suc=True
            for i in ul.obj_list:
                if isinstance(i,obj_bulletPlayer):
                    suc=False
            if suc:
                ul.instance_create(self.x,self.y,obj_bulletPlayer)
        if self.hsp<0 and self.x>16 or self.hsp>0 and self.x<rm_width-16:  
            self.x+=self.hsp*self.speed

    def draw(self):
        self.draw_self()

def restart(): #restart function
    ul.obj_list=[]
    player = ul.instance_create(320,643,obj_player) #player create
    obj_alliens.move=1
    obj_alliens.speed=35
    obj_alliens.animFrame=0
    for i in range(1,56):
        allien=ul.instance_create(40+((52*i)-(52*11*m.floor((i-1)/11))),20+52*m.ceil(i/11),obj_alliens) 
        if i<=11:
            allien.sprite=spr_allien1
        elif i<=33:
            allien.sprite=spr_allien2
        elif i<=55:
            allien.sprite=spr_allien3
    
def levelUp():
    obj_alliens.move=1
    if obj_alliens.speed<10:
        obj_alliens.speed-=1
    else:
        obj_alliens.speed-=5
    obj_alliens.animFrame=0
    for i in range(1,56):
        allien=ul.instance_create(40+((52*i)-(52*11*m.floor((i-1)/11))),20+52*m.ceil(i/11),obj_alliens) 
        if i<=11:
            allien.sprite=spr_allien1
        elif i<=33:
            allien.sprite=spr_allien2
        elif i<=55:
            allien.sprite=spr_allien3
 

player = ul.instance_create(320,643,obj_player) #player create

for i in range(1,56):
    allien=ul.instance_create(40+((52*i)-(52*11*m.floor((i-1)/11))),20+52*m.ceil(i/11),obj_alliens) 
    if i<=11:
        allien.sprite=spr_allien1
    elif i<=33:
        allien.sprite=spr_allien2
    elif i<=55:
        allien.sprite=spr_allien3
    
    #alliens craete


run=True
while (run):
    for event in pg.event.get():
        if event.type == pg.QUIT:
            run = False
    keys=pg.key.get_pressed()  #list of pressed keys
    win.fill((0,0,0))
    obj_alliens.alive=False
    for instance in ul.obj_list:
        instance.step()
        instance.draw()
    if obj_alliens.alive==False:
        levelUp()
    pg.display.update()
    pg.time.delay(16)
pg.quit()







